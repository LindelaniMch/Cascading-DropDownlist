﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DropDropDrop.Models
{
    public class StudentModel
    {
        public IList<SelectListItem> StateNames { get; set; }
        public IList<SelectListItem> DistrictNames { get; set; }

    }
}